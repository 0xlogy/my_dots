local awful = require("awful")
local gears = require("gears")

modkey = "Mod4"
altkey = "Mod1"

clientkeys = gears.table.join(
	--[[
    awful.key({ modkey,           }, "f",
        function (c)
            c.fullscreen = not c.fullscreen
            c:raise()
        end,
        {description = "toggle fullscreen", group = "client"}),
	--]]
    awful.key({ modkey,           }, "#41", -- "f"
        function (c)
            c.fullscreen = not c.fullscreen
            c:raise()
        end,
        {description = "toggle fullscreen", group = "client"}),
    awful.key({ modkey, "Control"   }, "c",      function (c) c:kill()                         end,
              {description = "close", group = "client"}),
    awful.key({         "Mod1"      }, "F4",     function (c) c:kill()                         end,
	          {description = "close", group = "client"}),
    awful.key({ modkey, "Control" }, "space",  awful.client.floating.toggle                     ,
              {description = "toggle floating", group = "client"}),
    awful.key({ modkey, "Control" }, "Return", function (c) c:swap(awful.client.getmaster()) end,
              {description = "move to master", group = "client"}),

	-- "o" key
    awful.key({ modkey,           }, "#32",      function (c) c:move_to_screen()               end,
              {description = "move to screen", group = "client"}),
    awful.key({ modkey,           }, "t",      function (c) c.ontop = not c.ontop            end,
              {description = "toggle keep on top", group = "client"}),
    awful.key({ modkey,           }, "n",
        function (c)
            -- The client currently has the input focus, so it cannot be
            -- minimized, since minimized clients can't have the focus.
            c.minimized = true
        end ,
        {description = "minimize", group = "client"}),
	--[[
    awful.key({ modkey,           }, "m",
        function (c)
            c.maximized = not c.maximized
            c:raise()
        end ,
        {description = "(un)maximize", group = "client"}),
    --]]
    awful.key({ modkey,           }, "#47", -- "m" on an azerty keyboard
        function (c)
            c.maximized = not c.maximized
            c:raise()
        end ,
        {description = "(un)maximize", group = "client"}),
    awful.key({ modkey, "Control" }, "#47",
        function (c)
            c.maximized_vertical = not c.maximized_vertical
            c:raise()
        end ,
        {description = "(un)maximize vertically", group = "client"}),
    awful.key({ modkey, "Shift"   }, "#47",
        function (c)
            c.maximized_horizontal = not c.maximized_horizontal
            c:raise()
        end ,
        {description = "(un)maximize horizontally", group = "client"}),
	
	awful.key(
		{modkey, }, "#59", -- ; on an azerty keyboard
		function ()
			awful.util.spawn("splatmoji --disable-emoji-db type", false)
		end,
		{description = "kaomoji drawer (requires splatmoji)", group = "other"}
	)
)

-- CREATE A FILE AT
-- ~/.config/local_awesome/custom_clientkeys.lua
-- containing something like:
--[[
-- local awful = require("awful")
-- local gears = require("gears")
--
-- local modkey = "Mod4"
-- local altkey = "Mod1"
--
-- local custom_clientkeys = gears.table.join(
--    awful.key({ modkey, altkey }, "p",
--       function (c)
--          -- c is the client so for example:
--          c.maximized_horizontal = not c.maximized_horizontal
--          c:raise()
--       end,
--       {description = "custom desc", group = "custom group"}
--    ),
-- )
--
-- return custom_clientkeys
--]]

local has_custom_ck, custom_clientkeys = pcall(require, "custom_clientkeys")
if has_custom_ck then
	clientkeys = gears.table.join(clientkeys, custom_clientkeys)
end

return clientkeys
