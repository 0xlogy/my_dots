local awful = require("awful")
local gears = require("gears")
clientkeys = require("conf.clientkeys")
clientbuttons = require("conf.clientbuttons")

return function(beautiful)
	-- {{{ Rules
	-- Rules to apply to new clients (through the "manage" signal).
	awful.rules.rules = {
		-- All clients will match this rule.
		{ rule = { },
		  properties = { border_width = beautiful.border_width,
						 border_color = beautiful.border_normal,
						 focus = awful.client.focus.filter,
						 size_hints_honor = false,
						 raise = true,
						 keys = clientkeys,
						 buttons = clientbuttons,
						 screen = awful.screen.preferred,
						 placement = awful.placement.no_overlap+awful.placement.no_offscreen
		 }
		},

		-- Floating clients.
		{ rule_any = {
			instance = {
			  "DTA",  -- Firefox addon DownThemAll.
			  "copyq",  -- Includes session name in class.
			  "pinentry",
			},
			class = {
			  "Arandr",
			  "Blueman-manager",
			  "Gpick",
			  "Kruler",
			  "MessageWin",  -- kalarm.
			  "Sxiv",
			  "Tor Browser", -- Needs a fixed window size to avoid fingerprinting by screen size.
			  "Wpa_gui",
			  "veromix",
			  "xtightvncviewer"},

			-- Note that the name property shown in xprop might be set slightly after creation of the client
			-- and the name shown there might not match defined rules here.
			name = {
			  "Event Tester",  -- xev.
			},
			role = {
			  "AlarmWindow",  -- Thunderbird's calendar.
			  "ConfigManager",  -- Thunderbird's about:config.
			  "pop-up",       -- e.g. Google Chrome's (detached) Developer Tools.
			}
		  }, properties = { floating = true }},


		-- to get class and instance:
		-- $ xprop WM_CLASS
		-- then click the window
		-- FIRST string is INSTANCE
		-- SECOND string is CLASS

		-- do not add titlebars to normal clients and dialogs
		{ rule_any = {type = { "normal", "dialog" }
		  }, properties = { titlebars_enabled = false }
		},



		-- Set browsers to always map on the 1st tag on screen 1.
		{ rule_any = { class = {"Waterfox", "firefox", "Chromium"} },
			properties = {
				screen = 1,
				tag = screen.primary.tags[1],
				maximized = true
			}
		}, --www
		
		{ rule_any =
			{
				name = {"PlayOnLinux", "Steam"},
				class = { "Steam", "MultiMC5", "Lutris", "Zenity" }
				-- zenity = steam update prompt
			},
			properties = { screen = 1, tag = screen.primary.tags[5] }
		}, --games
		
		{ rule_any =
			{
				class = { "TelegramDesktop" }
			},
			properties = { screen = 1, tag = screen.primary.tags[7] }
		}, --Telegram
		
		{ rule_any = { class = { "Signal", "Hexchat" } },
			properties = {
				screen = 1,
				tag = screen.primary.tags[7],
				maximized = true
			}
		},

		-- Set keepassxc to always map on the 8th tag on screen 1.
		{ rule_any = 
			{
				class = { "KeePassXC", "NordPass" }
			},
			properties = {
				screen = 1,
				tag = screen.primary.tags[8]
				, maximized = true
			}
		},
		
		{ rule_any = { class = { "discord", "lightcord", "Ripcord" } },
			properties = {
				screen = 1,
				tag = screen.primary.tags[9],
				maximized = true
			}
		}, --DC

		{	rule_all =
				{
					class = "JetBrains Toolbox",
					instance = "jetbrains-toolbox"
				},
			properties =
				{
					maximized = true
				}
		},

		{ rule_any = {
			class = {"Guake", "GLava", "Dwarf_Fortress", "lagrange"},
			name = {"Steam"}
			}, properties = { 
				maximized = true
			}
		},

		-- these programs will start in fullscreen (mostly for games)
		{ rule_any = {
				class = {
					"Minecraft*",
					"endless-sky",
					"le.x86_64.linux.bin"
				}
			},
			properties = { fullscreen = true }
		},
	}
	-- CREATE A FILE AT
	-- ~/.config/local_awesome/custom_rules.lua
	-- containing something like:
	--[[
	-- local awful = require("awful")
	-- local gears = require("gears")
	--
	-- local custom_rules = {
	-- 	{ rule_any = { class = {"Microsoft Teams - Preview" } },
	-- 		properties = {
	-- 			-- screen = 2,
	-- 			-- tag = screen.primary.tags[1],
	-- 			screen = 1,
	-- 			tag = screen.primary.tags[2],
	-- 			maximized = true
	-- 		}
	-- 	},
	-- }
	--
	-- return custom_rules
	--]]
	
	local has_custom_rules, custom_rules = pcall(require, "custom_rules")
	if has_custom_rules then
		awful.rules.rules = gears.table.join(awful.rules.rules, custom_rules)
	end
	-- }}}
end

