local theme = {}
function script_path()
    local str = debug.getinfo(2, "S").source:sub(2)
    return str:match("(.*/)")
end
function file_exists(name)
   local f=io.open(name,"r")
   if f~=nil then io.close(f) return true else return false end
end
--theme.dir           = os.getenv("HOME") .. "/.config/awesome/darkgeem"
theme.dir           = script_path()
theme.zenburn_dir   = require("awful.util").get_themes_dir() .. "zenburn"

theme.font          = "terminus 10"

theme.wallpaper     = theme.dir .. "/Lune.jpg"
if file_exists(os.getenv("HOME") .. "/.wallpapers/1.png") then
	theme.wallpaper_1 = os.getenv("HOME") .. "/.wallpapers/1.png"
end
if file_exists(os.getenv("HOME") .. "/.wallpapers/2.png") then
	theme.wallpaper_2 = os.getenv("HOME") .. "/.wallpapers/2.png"
end

theme.bg_normal     = "#0a0b0c"
theme.bg_focus      = "#abb8c3"
theme.bg_urgent     = "#402030"
theme.bg_minimize   = "#000000"
--theme.bg_systray    = theme.bg_normal

theme.fg_normal     = "#839496"
--theme.fg_focus      = "#d0d0d0"
theme.fg_focus      = "#0a0b0c"
theme.fg_urgent     = "#cc4040"
theme.fg_minimize   = "#584058"

theme.useless_gap   = dpi(0)
theme.border_width  = dpi(1)
theme.border_normal = "#44494e"
theme.border_focus  = "#abb8c3"
theme.border_marked = "#323b4a"

theme.wibar_size    = dpi(22)

--theme.taglist_fg_focus  = "#00d0d0"
--theme.tasklist_bg_focus = "#0e0e0e"
--theme.tasklist_fg_focus = "#00d0d0"

-- Generate taglist squares:
theme.taglist_square_size = dpi(6)

theme.taglist_squares_sel   = theme.dir .. "/icons/square_sel.png"
theme.taglist_squares_unsel = theme.dir .. "/icons/square_unsel.png"


theme.awesome_icon = theme.dir .."/icons/awesome.png"

theme.menu_submenu_icon  = theme.dir .. "/icons/submenu.png"
theme.menu_height        = dpi(20)
theme.menu_width         = dpi(140)

theme.tasklist_plain_task_name = false
theme.tasklist_disable_icon    = true

theme.layout_fairh = theme.zenburn_dir.."/layouts/fairh.png"
theme.layout_fairv = theme.zenburn_dir.."/layouts/fairv.png"
theme.layout_floating  = theme.zenburn_dir.."/layouts/floating.png"
theme.layout_magnifier = theme.zenburn_dir.."/layouts/magnifier.png"
theme.layout_max = theme.zenburn_dir.."/layouts/max.png"
theme.layout_fullscreen = theme.zenburn_dir.."/layouts/fullscreen.png"
theme.layout_tilebottom = theme.zenburn_dir.."/layouts/tilebottom.png"
theme.layout_tileleft   = theme.zenburn_dir.."/layouts/tileleft.png"
theme.layout_tile = theme.zenburn_dir.."/layouts/tile.png"
theme.layout_tiletop = theme.zenburn_dir.."/layouts/tiletop.png"
theme.layout_spiral  = theme.zenburn_dir.."/layouts/spiral.png"
theme.layout_dwindle = theme.zenburn_dir.."/layouts/dwindle.png"
theme.layout_cornernw = theme.zenburn_dir.."/layouts/cornernw.png"
theme.layout_cornerne = theme.zenburn_dir.."/layouts/cornerne.png"
theme.layout_cornersw = theme.zenburn_dir.."/layouts/cornersw.png"
theme.layout_cornerse = theme.zenburn_dir.."/layouts/cornerse.png"

return theme
