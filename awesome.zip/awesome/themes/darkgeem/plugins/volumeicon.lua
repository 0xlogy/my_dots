local wibox = require("wibox")
local awful = require("awful")

-- Create a text widget for displaying the volume percentage
local volume_widget = wibox.widget.textbox()

-- Function to update the volume widget
local function update_volume_widget()
    -- awful.spawn.easy_async("amixer sget Master", function(stdout)
    awful.spawn.easy_async("pamixer --get-volume", function(volume)
		awful.spawn.easy_async("pamixer --get-mute", function(muted)
			if (volume) then
				local muted_pre = " "
				local muted_post = "%"
				if (muted:match("true") == "true") then
					muted_pre = " "
				end
				volume_widget:set_text(muted_pre .. volume .. muted_post)
			else
				volume_widget:set_text("volume unavailable")
			end
		end)
    end)
end

-- Update the volume widget initially
update_volume_widget()

-- Create a timer to update the volume widget every [timeout]
local volume_timer = timer({ timeout = 0.5 })
volume_timer:connect_signal("timeout", update_volume_widget)
volume_timer:start()

-- Return the volume widget
return volume_widget
