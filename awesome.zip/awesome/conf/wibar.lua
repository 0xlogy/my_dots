local awful = require("awful")
awful.util.taglist_buttons = my_table.join(
    awful.button({ }, 1, function(t) t:view_only() end), -- lmb = go to tag
    awful.button({ modkey }, 1, function(t) -- [win]+lmb = move window to tag
        if client.focus then
            client.focus:move_to_tag(t)
        end
    end),
    awful.button({ }, 3, awful.tag.viewtoggle), -- rmb = enable/disable tag
    awful.button({ modkey }, 3, function(t) -- [win]+rmb = copy window to tag
        if client.focus then
            client.focus:toggle_tag(t)
        end
    end)
)

awful.util.tasklist_buttons = my_table.join(
    awful.button({ }, 1, function (c) -- lmb = either go to window if not focused, or minimize it
        if c == client.focus then
            c.minimized = true
        else
            --c:emit_signal("request::activate", "tasklist", {raise = true})<Paste>

            -- Without this, the following
            -- :isvisible() makes no sense
            c.minimized = false
            if not c:isvisible() and c.first_tag then
                c.first_tag:view_only()
            end
            -- This will also un-minimize
            -- the client, if needed
            client.focus = c
            c:raise()
        end
    end),
    awful.button({ }, 2, function (c) c:kill() end) -- mmb = close window
)

