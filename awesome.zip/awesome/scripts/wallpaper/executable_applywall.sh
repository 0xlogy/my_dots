#!/bin/bash

wpath="$(cat ${HOME}/.config/awesome/scripts/wallpaper/wallpaper_path)"
feh --bg-fill "$wpath"
