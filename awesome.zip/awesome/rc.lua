-- If LuaRocks is installed, make sure that packages installed through it are
-- found (e.g. lgi). If LuaRocks is not installed, do nothing.
pcall(require, "luarocks.loader")

--local awesome, client, mouse, screen, tag = awesome, client, mouse, screen, tag
--local ipairs, string, os, table, tostring, tonumber, type = ipairs, string, os, table, tostring, tonumber, type

-- Standard awesome library
local gears = require("gears")
local awful = require("awful")
              require("awful.autofocus")

-- Theme handling library
local beautiful = require("beautiful")

-- Notification library
local naughty = require("naughty")


-- check if file exists
function file_exists(file)
	local ok, err, code = os.rename(file, file)
	if not ok then
		if code == 13 then
			-- Permission denied, but it exists
			return true
		end
	end
	return ok, err
end
local laws = os.getenv('HOME') .. '/.config/local_awesome'
if file_exists(laws .. '/') then
	package.path = package.path .. ';' .. laws .. '/?.lua'
end


-- Run garbage collector regularly to prevent memory leaks
gears.timer {
	timeout = 30,
	autostart = true,
	callback = function () collectgarbage() end
}

my_table = awful.util.table or gears.table -- 4.{0,1} compatibility
dpi = require("beautiful.xresources").apply_dpi


-- local cyclefocus = require('cyclefocus')
-- cyclefocus.display_notifications = false


-- {{{ Error handling
-- Check if awesome encountered an error during startup and fell back to
-- another config (This code will only ever execute for the fallback config)
if awesome.startup_errors then
    naughty.notify({ preset = naughty.config.presets.critical,
                     title = "Oops, there were errors during startup!",
                     text = awesome.startup_errors })
end

-- Handle runtime errors after startup
do
    local in_error = false
    awesome.connect_signal("debug::error", function (err)
        -- Make sure we don't go into an endless error loop
        if in_error then return end
        in_error = true

        naughty.notify({ preset = naughty.config.presets.critical,
                         title = "Oops, an error happened!",
                         text = tostring(err) })
        in_error = false
    end)
end
-- }}}

-- {{{ Variable definitions
-- Themes define colours, icons, font and wallpapers.
local chosen_theme = "darkgeem"
-- beautiful.init(gears.filesystem.get_themes_dir() .. "default/theme.lua")

-- This is used later as the default terminal and editor to run.
-- terminal = "mate-terminal"
-- terminal = "uxterm"
-- terminal = "urxvt"
-- warning: urxvtc requires urxvtd to be started
-- terminal = "urxvtc"
terminal = "st"
editor = os.getenv("EDITOR") or "vim"
browser = os.getenv("BROWSER") or "firefox"
geminibrowser = "lagrange"
file_explorer = "thunar"
lockscreen_cmd = "env \
XSECURELOCK_AUTH_BACKGROUND_COLOR=#000000 \
XSECURELOCK_AUTH_FOREGROUND_COLOR=#abb8c3 \
XSECURELOCK_PASSWORD_PROMPT=time \
XSECURELOCK_BLANK_TIMEOUT=-1 \
XSECURELOCK_BLANK_DPMS_STATE=on \
XSECURELOCK_DISCARD_FIRST_KEYPRESS=0 \
XSECURELOCK_BLANK_DPMS_STATE=on \
XSECURELOCK_SAVER=saver_mpv \
XSECURELOCK_IMAGE_DURATION_SECONDS=5 \
'XSECURELOCK_LIST_VIDEOS_COMMAND=find ~/.lock_images/ -type f' \
xsecurelock"
suspend_cmd = lockscreen_cmd .. " -- systemctl suspend"
hibernate_cmd = lockscreen_cmd .. " -- systemctl hibernate"
editor_cmd = terminal .. " -e " .. editor

awful.util.terminal = terminal

require("conf.layout")
-- }}}


-- {{{ Wibar
require("conf.wibar")

beautiful.init(string.format("%s/.config/awesome/themes/%s/theme.lua", os.getenv("HOME"), chosen_theme))
beautiful.hotkeys_modifiers_fg = '#008080'
beautiful.hotkeys_font = 'Terminus 12'
beautiful.hotkeys_description_font = 'Terminus 10'

-- Re-set wallpaper when a screen's geometry changes (e.g. different resolution)
--screen.connect_signal("property::geometry", set_wallpaper)
--[[
local myawesomemenu = {
    { "hotkeys", function() return false, hotkeys_popup.show_help end },
    { "manual", terminal .. " -e man awesome" },
    { "edit config", string.format("%s -e %s %s", terminal, editor, awesome.conffile) },
    { "restart", awesome.restart },
    { "quit", function() awesome.quit() end }
}
--]]

-- hotkey hints
local hotkeys_popup = require("conf.hotkeys")(beautiful)

screen.connect_signal("property::geometry", function(s)
    -- Wallpaper
    if beautiful.wallpaper then
        local wallpaper = beautiful.wallpaper
        -- If wallpaper is a function, call it with the screen
        if type(wallpaper) == "function" then
            wallpaper = wallpaper(s)
        end
        gears.wallpaper.maximized(wallpaper, s, true)
    end
end)

-- disable borders if maximized
screen.connect_signal("arrange", function (s)
    for _, c in pairs(s.clients) do
        if c.maximized then
            c.border_width = 0
        else
            c.border_width = beautiful.border_width
        end
    end
end)

awful.screen.connect_for_each_screen(function(s) beautiful.at_screen_connect(s) end)
-- }}}

require("conf.rules")(beautiful)

-- {{{ Signals
-- Signal function to execute when a new client appears.
client.connect_signal("manage", function (c)
    -- Set the windows at the slave,
    -- i.e. put it at the end of others instead of setting it master.
    -- if not awesome.startup then awful.client.setslave(c) end

    if awesome.startup
      and not c.size_hints.user_position
      and not c.size_hints.program_position then
        -- Prevent clients from being unreachable after screen count changes.
        awful.placement.no_offscreen(c)
    end
end)


-- Enable sloppy focus, so that focus follows mouse.
client.connect_signal("mouse::enter", function(c)
    c:emit_signal("request::activate", "mouse_enter", {raise = false})
end)

client.connect_signal("focus", function(c) c.border_color = beautiful.border_focus end)
client.connect_signal("unfocus", function(c) c.border_color = beautiful.border_normal end)
-- }}}


-- autostarts programs
awful.spawn.with_shell("~/.config/awesome/scripts/executabe_autorun.sh")

