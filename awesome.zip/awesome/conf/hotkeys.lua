return function (beautiful)
	local awful = require("awful")
	local gears = require("gears")
	local cyclefocus = require("plugins.cyclefocus")
	cyclefocus.display_notifications = false

	local hotkeys_popup = require("awful.hotkeys_popup").widget

	-- Create the rule that we will use to match for the application.
	local fire_rule = { class = { "firefox", "Firefox" } }
	for group_name, group_data in pairs({
		["Firefox: tabs"] = { color = "#009F00", rule_any = fire_rule }
	}) do
		hotkeys_popup.add_group_rules(group_name, group_data)
	end

	modkey = "Mod4"
	altkey = "Mod1"



	-- Table with all of our hotkeys
	local firefox_keys = {

		["Firefox: tabs"] = {{
			modifiers = { "Mod1" },
			keys = {
				["1..9"] = "go to tab"
			}
		}, {
			modifiers = { "Ctrl" },
			keys = {
				t = "new tab",
				w = 'close tab',
				['Tab'] = "next tab"
			}
		}, {
			modifiers = { "Ctrl", "Shift" },
			keys = {
			  ['Tab'] = "previous tab"
			}
		}}
	}

	hotkeys_popup.add_hotkeys(firefox_keys)

	-- {{{ Key bindings

	globalkeys = gears.table.join(
	--[[
		awful.key({ modkey,           }, "s",      hotkeys_popup.show_help,
				  {description="show help", group="awesome"}),
	--]]
		awful.key({ modkey,           }, "#39",      hotkeys_popup.show_help,
				  {description="show help", group="awesome"}),
		awful.key({ modkey,           }, "Left",   awful.tag.viewprev,
				  {description = "view previous", group = "tag"}),
		awful.key({ modkey,           }, "Right",  awful.tag.viewnext,
				  {description = "view next", group = "tag"}),
		awful.key({ modkey,           }, "Escape", awful.tag.history.restore,
				  {description = "go back", group = "tag"}),

		awful.key({ modkey,           }, "Tab",
			function ()
				awful.client.focus.byidx( 1)
			end,
			{description = "focus next by index", group = "client"}
		),
		awful.key({ modkey,           }, "j",
			function ()
				awful.client.focus.byidx( 1)
			end,
			{description = "focus next by index", group = "client"}
		),
		awful.key({ modkey,           }, "k",
			function ()
				awful.client.focus.byidx(-1)
			end,
			{description = "focus previous by index", group = "client"}
		),

		-- Layout manipulation
		awful.key({ modkey, "Shift"   }, "j", function () awful.client.swap.byidx(  1)    end,
				  {description = "swap with next client by index", group = "client"}),
		awful.key({ modkey, "Shift"   }, "k", function () awful.client.swap.byidx( -1)    end,
				  {description = "swap with previous client by index", group = "client"}),
		awful.key({ modkey, "Control" }, "j", function () awful.screen.focus_relative( 1) end,
				  {description = "focus the next screen", group = "screen"}),
		awful.key({ modkey, "Control" }, "k", function () awful.screen.focus_relative(-1) end,
				  {description = "focus the previous screen", group = "screen"}),
		--[[
		awful.key({ modkey,           }, "u", awful.client.urgent.jumpto,
				  {description = "jump to urgent client", group = "client"}),
		--]]
		awful.key({ modkey,           }, "#30", awful.client.urgent.jumpto,
				  {description = "jump to urgent client", group = "client"}),
		--awful.key({ "Mod1",           }, "Tab",
		--    function ()
		--	    switcher.switch( 1, "Mod1", "Alt_L", "Shift", "Tab")
		--	end),
		--awful.key({ "Mod1", "Shift"   }, "Tab",
		--	function ()
		--		switcher.switch(-1, "Mod1", "Alt_L", "Shift", "Tab")
		--	end),
		--awful.key({ modkey,           }, "Tab",
		--    function ()
		--        awful.client.focus.history.previous()
		--        if client.focus then
		--            client.focus:raise()
		--        end
		--    end,
		--    {description = "go back", group = "client"}),
		
		awful.key({ modkey }, "l", function ()
		  awful.util.spawn(lockscreen_cmd, false)
		  end,
		  {description = "lock the screen", group = "awesome"}
		),

		awful.key({ modkey, "Control", "Shift" }, "s", function ()
		  awful.util.spawn(suspend_cmd, false)
		  end,
		  {description = "suspend system (sleep)", group = "awesome"}
		),

		awful.key({ modkey, "Control", "Shift" }, "h", function ()
		  awful.util.spawn(hibernate_cmd, false)
		  end,
		  {description = "hibernate system (suspend to ram)", group = "awesome"}
		),


		cyclefocus.key({ altkey, }, "Tab", {
			cycle_filters = { cyclefocus.filters.same_screen, cyclefocus.filters.common_tag },
			keys = {'Tab', 'ISO_Left_Tab'}
		}),

		--[[
		cyclefocus.key({ altkey, }, "Tab", {
			cycle_filters = { cyclefocus.filters.same_screen, cyclefocus.filters.common_tag },
			keys = {'Tab', 'ISO_Left_Tab'}
		}),
		--]]

		-- Standard program
		awful.key({ modkey,           }, "Return", function () awful.spawn(terminal) end,
				  {description = "open a terminal", group = "launcher"}),
		awful.key({ modkey,           }, "h", function () awful.spawn("xterm") end,
				  {description = "open XTerm", group = "launcher"}),  -- Requires xterm
		-- "r"
		awful.key({ modkey, "Control" }, "#27", awesome.restart,
				  {description = "reload awesome", group = "awesome"}),
		awful.key({ modkey, "Shift"   }, "q", awesome.quit,
				  {description = "quit awesome", group = "awesome"}),

		awful.key({ modkey, altkey    }, "l",     function () awful.tag.incmwfact( 0.05)          end,
				  {description = "increase master width factor", group = "layout"}),
		awful.key({ modkey, altkey    }, "h",     function () awful.tag.incmwfact(-0.05)          end,
				  {description = "decrease master width factor", group = "layout"}),
		awful.key({ modkey, "Shift"   }, "h",     function () awful.tag.incnmaster( 1, nil, true) end,
				  {description = "increase the number of master clients", group = "layout"}),
		awful.key({ modkey, "Shift"   }, "l",     function () awful.tag.incnmaster(-1, nil, true) end,
				  {description = "decrease the number of master clients", group = "layout"}),
		awful.key({ modkey, "Control" }, "h",     function () awful.tag.incncol( 1, nil, true)    end,
				  {description = "increase the number of columns", group = "layout"}),
		awful.key({ modkey, "Control" }, "l",     function () awful.tag.incncol(-1, nil, true)    end,
				  {description = "decrease the number of columns", group = "layout"}),
		awful.key({ modkey,           }, "space", function () awful.layout.inc( 1)                end,
				  {description = "select next", group = "layout"}),
		awful.key({ modkey, "Shift"   }, "space", function () awful.layout.inc(-1)                end,
				  {description = "select previous", group = "layout"}),

		awful.key({ modkey, "Control" }, "n",
				  function ()
					  local c = awful.client.restore()
					  -- Focus restored client
					  if c then
						c:emit_signal(
							"request::activate", "key.unminimize", {raise = true}
						)
					  end
				  end,
				  {description = "restore minimized", group = "client"}),

		-- Prompt "r"
		awful.key({ modkey },            "#27",     function () awful.screen.focused().mypromptbox:run() end,
				  {description = "run prompt", group = "launcher"}),

		--[[
		awful.key({ modkey }, "c",
				  function ()
					  awful.prompt.run {
						prompt       = "Run with graphics card: ",
						textbox      = awful.screen.focused().mypromptbox.widget,
						exe_callback = function(input)
							awful.util.spawn("env DRI_PRIME=1 "..input, false)
						end;
						history_path = awful.util.get_cache_dir() .. "/history_gc"
					  }
				  end,
				  {description = "run with graphics card prompt", group = "awesome"}),
		--]]
		awful.key({ modkey }, "x",
				  function ()
					  awful.prompt.run {
						prompt       = "Run Lua code: ",
						textbox      = awful.screen.focused().mypromptbox.widget,
						exe_callback = awful.util.eval,
						history_path = awful.util.get_cache_dir() .. "/history_eval"
					  }
				  end,
				  {description = "lua execute prompt", group = "awesome"}),
		-- Menubar
		--awful.key({ modkey }, "p", function() menubar.show() end,
		--          {description = "show the menubar", group = "launcher"}),
		
		-- Volume Keys
	   awful.key({ modkey }, "F2", function () -- vol-
		 -- beautiful.volume_widget:dec()
		 awful.util.spawn("pamixer -d 5", false)
		 --awful.util.spawn("amixer -q -D pulse sset Master 5%-", false)
	   end,
	   {description = "volume +5%", group = "media control"}),
	   awful.key({}, "XF86AudioLowerVolume", function () -- vol-
		 -- beautiful.volume_widget:dec()
		 awful.util.spawn("pamixer -d 5", false)
		 --awful.util.spawn("amixer -q -D pulse sset Master 5%-", false)
	   end),
	   awful.key({ modkey }, "F3", function () -- vol+
		 -- beautiful.volume_widget:inc()
		 awful.util.spawn("pamixer -i 5", false)
		 --awful.util.spawn("amixer -q -D pulse sset Master 5%+", false)
		 end,
		 {description = "volume -5%", group = "media control"}
	   ),
	   awful.key({}, "XF86AudioRaiseVolume", function () -- vol+
		 -- beautiful.volume_widget:inc()
		 awful.util.spawn("pamixer -i 5", false)
		 --awful.util.spawn("amixer -q -D pulse sset Master 5%+", false)
	   end),
	   awful.key({ modkey }, "F1", function () -- mute/unmute
		 -- beautiful.volume_widget:toggle()
		 awful.util.spawn("pamixer -t", false)
		 --awful.util.spawn("amixer -D pulse set Master 1+ toggle", false)
		 end,
		 {description = "toggle mute", group = "media control"}
	   ),
	   awful.key({}, "XF86AudioMute", function () -- mute/unmute
		 -- beautiful.volume_widget:toggle()
		 awful.util.spawn("pamixer -t", false)
		 --awful.util.spawn("amixer -D pulse set Master 1+ toggle", false)
	   end),
	   -- Media Keys
	   awful.key({ modkey, "Control" }, "Left", function() -- previous song
		 awful.util.spawn("playerctl previous", false)  -- Requires placerctl
		 awful.util.spawn("mocp --previous", false)  -- Requires moc
		 end,
		 {description = "previous", group = "media control"}
	   ),
	   awful.key({ modkey, "Control" }, "Right", function()
		 awful.util.spawn("playerctl next", false)  -- Requires playerctl
		 awful.util.spawn("mocp --next", false)  -- Requires moc
		 end,
		 {description = "next", group = "media control"}
	   ),
	   awful.key({ modkey }, "Down", function()
		 awful.util.spawn("playerctl play-pause", false)  -- Requires playerctl
		 awful.util.spawn("mocp --toggle-pause", false)  -- Requires moc
		 end,
		 {description = "play/pause", group = "media control"}
	   ),
	   awful.key({ modkey, "Control" }, "Down", function()
		 awful.util.spawn("playerctl stop", false)  -- Requires playerctl
		 awful.util.spawn("mocp --stop", false)  -- Requires moc
		 end,
		 {description = "stop", group = "media control"}
	   ),
	   awful.key({}, "XF86AudioPlay", function()
		 awful.util.spawn("playerctl play-pause", false)  -- Requires playerctl
	   end),
	   awful.key({}, "XF86AudioNext", function()
		 awful.util.spawn("playerctl next", false)  -- Requires playerctl
	   end),
	   awful.key({}, "XF86AudioPrev", function()
		 awful.util.spawn("playerctl previous", false)  -- Requires playerctl
	   end),
	   awful.key({}, "XF86AudioStop", function()
		 awful.util.spawn("playerctl stop", false)  -- Requires playerctl
	   end),

	   awful.key({}, "XF86MonBrightnessUp", function()
		 awful.util.spawn("light -A 10", false)  -- Requires light
	   end),
	   awful.key({}, "XF86MonBrightnessDown", function()
		 awful.util.spawn("light -U 10", false)  -- Requires light
	   end),
	   --awful.key({}, "XF86MonBrightnessUp", function()
	   --  awful.util.spawn("xbacklight -inc 10", false)
	   --end),
	   --awful.key({}, "XF86MonBrightnessDown", function()
	   --  awful.util.spawn("xbacklight -dec 10", false)
	   --end),
	   
	   -- "s"
	   awful.key({modkey, "Shift" }, "#39", function()
		 awful.util.spawn("bash -c 'maim -s |xclip -selection clipboard -t image/png'", false)  -- Requires maim+xclip
	   end)
	   -- "s"
	   ,awful.key({modkey, "Ctrl" }, "#39", function()
		 awful.util.spawn("bash -c 'maim |xclip -selection clipboard -t image/png'", false)  -- Requires maim+xclip
	   end)
	   --[[
	   ,awful.key({}, "Print", function()
		 awful.util.spawn("bash -c 'maim |xclip -selection clipboard -t image/png'", false)  -- Requires maim+xclip
	   end)
	   --]]

	   --[[
	   --]]
	   ,awful.key({}, "Print", function()
		 awful.util.spawn("flameshot gui", false)  -- Requires flameshot
	   end)
	   --]]

	   --[[
	   ,awful.key({ modkey,}, "w", function()
		 awful.util.spawn(browser, false)
		 end,
		 {description = "open web browser", group = "launcher"}
	   )
	   --]]
	   ,awful.key({ modkey,}, "#52", function() -- "w" on azerty, "z" on qwerty
		 awful.util.spawn(browser, false)
		 end,
		 {description = "open web browser", group = "launcher"}
	   )

	   ,awful.key({ modkey,}, "g", function()
		 awful.util.spawn(geminibrowser, false)
		 end,
		 {description = "open gemini browser", group = "launcher"}
	   )

	   ,awful.key({ modkey,}, "e", function()
		 awful.util.spawn(file_explorer, false)
		 end,
		 {description = "open file explorer", group = "launcher"}
	   )

	   ,awful.key({ modkey,}, "c", function()
		 awful.util.spawn("nordvpn c CH", false)  -- Requires nordvpn-bin
		 end,
		 {description = "connect to Switzerland (nordvpn)", group = "VPN"}
	   )

	   ,awful.key({ modkey,}, "d", function()
		 awful.util.spawn("nordvpn d", false)  -- Requires nordvpn-bin
		 end,
		 {description = "disconnect nordvpn", group = "VPN"}
	   )

	)

	-- Bind all key numbers to tags.
	-- Be careful: we use keycodes to make it work on any keyboard layout.
	-- This should map on the top row of your keyboard, usually 1 to 9.

	local custom_key_help = {
		["tag"] = {
			{
				modifiers = { modkey },
				keys = {
					["1..9"] = "view tag 1..9"
				}
			},
			{
				modifiers = { modkey, "Control" },
				keys = {
					["1..9"] = "toggle tag 1..9"
				}
			},
			{
				modifiers = { modkey, "Shift" },
				keys = {
					["1..9"] = "move focused client to tag 1..9"
				}
			},
			{
				modifiers = { modkey, "Control", "Shift" },
				keys = {
					["1..9"] = "toggle focused client on tag 1..9"
				}
			}
		}
	}
	hotkeys_popup.add_hotkeys(custom_key_help)


	for i = 1, 9 do
		globalkeys = gears.table.join(globalkeys,
			-- View tag only.
			awful.key({ modkey }, "#" .. i + 9,
					  function ()
							local screen = awful.screen.focused()
							local tag = screen.tags[i]
							if tag then
							   tag:view_only()
							end
					  end
					  ),
			-- Toggle tag display.
			awful.key({ modkey, "Control" }, "#" .. i + 9,
					  function ()
						  local screen = awful.screen.focused()
						  local tag = screen.tags[i]
						  if tag then
							 awful.tag.viewtoggle(tag)
						  end
					  end
					  ),
			-- Move client to tag.
			awful.key({ modkey, "Shift" }, "#" .. i + 9,
					  function ()
						  if client.focus then
							  local tag = client.focus.screen.tags[i]
							  if tag then
								  client.focus:move_to_tag(tag)
							  end
						 end
					  end
					  ),
			-- Toggle tag on focused client.
			awful.key({ modkey, "Control", "Shift" }, "#" .. i + 9,
					  function ()
						  if client.focus then
							  local tag = client.focus.screen.tags[i]
							  if tag then
								  client.focus:toggle_tag(tag)
							  end
						  end
					  end
					  )
		)
	end

	-- CREATE A FILE AT
	-- ~/.config/local_awesome/custom_hotkeys.lua
	-- containing something like:
	--[[
	-- local awful = require("awful")
	-- local gears = require("gears")
	--
	-- local modkey = "Mod4"
	-- local altkey = "Mod1"
	--
	-- local custom_globalkeys = gears.table.join(
	--    awful.key({modkey, "Control", "Shift"}, "h", function ()
	--          awful.util.spawn("xcowsay hello", false)
	--       end,
	--       {description = "CUSTOM DESCRIPTION", group = "CUSTOM"}
	--    )
	-- )
	--
	-- return custom_globalkeys
	--]]

	local has_custom_gk, custom_globalkeys = pcall(require, "custom_hotkeys")
	if has_custom_gk then
		globalkeys = gears.table.join(globalkeys, custom_globalkeys)
	end

	-- Set keys
	root.keys(globalkeys)
	-- }}}

	return hotkeys_popup
end
