function parent_dir(p)
	if (#p <= 1) then
		return p
	end
	if (p:sub(-1, -1) == "/") then
		p = p:sub(1, -2)
	end
	while (p:sub(-1, -1) ~= "/") do
		if (#p <= 1) then
			return p
		end
		p = p:sub(1, -2)
	end
	return p
end

return parent_dir

