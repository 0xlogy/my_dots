#!/usr/bin/env bash

function run {
	if which $1; then
		if ! pgrep -f $1 ;
		then
			$@&
		fi
	fi
}

function run_anyway {
	if which $1; then
		$@&
	fi
}

# applies stored wallpaper
# run ~/.config/awesome/scripts/wallpaper/applywall.sh
run pipewire
# X compositor (for transparency and effects)
run picom --config $HOME/.config/picom.conf

# network-manager tray applet
run nm-applet

# sets keyboard layout to fr_FR, and set Alt+Shift to toggle with en_GB
# run setxkbmap -layout fr,gb -option 'grp:alt_shift_toggle'

# runs thunar as daemon (so that explorer windows open faster)
run thunar --daemon

# system monitor over wallpaper
run conky

# urxvt daemon, allows for urxvtc use
# run urxvtd -q -f -o -m


# runs custom config after everything else (well, except for the delayed stuff)
if ls ~/.config/_awesome_autorun; then
	run_anyway bash ~/.config/_awesome_autorun
fi

#AFTER THAT, COMMANDS ARE DELAYED BY 15 SECONDS, BE CAREFUL
sleep 15
run pactl upload-sample $HOME/.config/awesome/media/bell.ogg bell.ogg  # uploads bell.ogg to pulseaudio
if pactl list |grep module-x11-bell; then
	echo "already exists" >/dev/null
else
	run pactl load-module module-x11-bell display=:0.0 sample=bell.ogg  # sets alarm bell to bell.ogg
fi
