---------------------------
-- Default awesome theme --
---------------------------

function script_path()
    local str = debug.getinfo(2, "S").source:sub(2)
    return str:match("(.*/)")
end
package.path = package.path .. ';' .. script_path() .. '/../?.lua'
package.path = package.path .. ';' .. script_path() .. '/../?.init.lua'

local theme_assets = require("beautiful.theme_assets")
local xresources = require("beautiful.xresources")

local gfs = require("gears.filesystem")
local themes_path = gfs.get_themes_dir()

local gears = require("gears")
local awful = require("awful")
local wibox = require("wibox")
local dpi   = require("beautiful.xresources").apply_dpi

--[[ -- notify that theme.lua has been loaded
local naughty = require("naughty")
naughty.notify({
    title = "theme.lua location",
    text = script_path(),
    height = 100,
    width = 400,
    timeout = 10
})
--]]

local theme = require("darkgeem.theme_vars")

local beautiful = require("beautiful")
beautiful.font               = theme.font
beautiful.menu_bg_normal     = theme.bg_normal
beautiful.menu_fg_normal     = theme.fg_normal
beautiful.menu_fg_focus      = theme.fg_focus
beautiful.awesome_icon       = theme.awesome_icon
beautiful.menu_submenu_icon  = theme.awesome_icon
beautiful.menu_height        = theme.menu_height
beautiful.menu_width         = theme.menu_width

local gray   = "#94928F"

--[[
local mylauncher = awful.widget.launcher({ 
            image = theme.awesome_icon,
            command = "jgmenu_run"
        })
--]]

---- WIDGETS ----

-- Battery
local battery_widget = require("darkgeem.plugins.battery")

-- Volume
local geem_volume_widget = require("darkgeem.plugins.volumeicon")

-- Volume (child of theme because needs access to inc/dec/toggle functions)
-- theme.volume_widget = require("darkgeem.plugins.volume-widget.volume")

-- Textclock
local mytextclock = wibox.widget.textclock(" %H:%M ")
mytextclock.font = theme.font

-- Calendar

local calendar_widget = require("darkgeem.plugins.calendar")
local cw = calendar_widget({
    theme = 'darkgeem',
    placement = 'top_right',
    radius = 1,
})
mytextclock:connect_signal("button::press",
    function(_, _, _, button)
        if button == 1 then cw.toggle() end
    end)

-- Keyboard layout
theme.kblayout = awful.widget.keyboardlayout()

-- Separators
local first = wibox.widget.textbox(' ')
local spr   = wibox.widget.textbox(' | ')
local spr_nospace = wibox.widget.textbox('|')
local qsdqsd = wibox.widget.textbox(themes_path)

-- Net speed
local net_speed_widget = require("darkgeem.plugins.net-speed-widget.net-speed")


-- get home var
local homedir = os.getenv("HOME")


-- APPLY

function theme.at_screen_connect(s)

    -- If wallpaper is a function, call it with the screen
    local wallpaper = theme.wallpaper
    if type(wallpaper) == "function" then
        wallpaper = wallpaper(s)
    end
    gears.wallpaper.centered(wallpaper, s)
    if (theme.wallpaper_1) then
        gears.wallpaper.fit(theme.wallpaper_1, s, "#101010")
        -- gears.wallpaper.centered(theme.wallpaper_1, s, "#ff0000", 0.4)
    end
    if (s.index > 1) then
        if (theme.wallpaper_2) then
            gears.wallpaper.fit(theme.wallpaper_2, s, "#101010")
            -- gears.wallpaper.centered(theme.wallpaper_2, s, "#211b27", 0.38)
        end
    end

    -- Tags
    awful.tag(awful.util.tagnames, s, awful.layout.taglays)

    -- Create a promptbox for each screen
    s.mypromptbox = awful.widget.prompt()

    -- Layout box
    s.mylayoutbox = awful.widget.layoutbox(s)

    -- Create a taglist widget
    s.mytaglist = awful.widget.taglist(s, awful.widget.taglist.filter.all, awful.util.taglist_buttons)

    -- Create a tasklist widget
    s.mytasklist = awful.widget.tasklist {
        screen = s,
        filter = awful.widget.tasklist.filter.currenttags,
        buttons = awful.util.tasklist_buttons,
        layout = {
            spacing = 8,
            spacing_widget = {
                widget       = spr_nospace
            },
            layout = wibox.layout.flex.horizontal
        },
    }

    -- Create the wibox
    s.mywibox = awful.wibar({ position = "bottom", screen = s, height = theme.wibar_size })

    -- Add widgets to the wibox
    s.mywibox:setup {
        layout = wibox.layout.align.horizontal,
        { -- Left widgets
            layout = wibox.layout.fixed.horizontal,
            -- mylauncher,
            -- first,
            s.mytaglist,
            spr,
            s.mylayoutbox,
            spr,
            s.mypromptbox
        },
        s.mytasklist, -- Middle widget
        { -- Right widgets
            layout = wibox.layout.fixed.horizontal,
            spr,
            net_speed_widget(),
            spr,
            theme.kblayout,
            -- spr,
            -- theme.volume_widget(),
            spr,
            geem_volume_widget,
            spr,
            battery_widget({font = theme.font}),
            spr,
            -- awful.widget.watch("bash -c 'bash \"" .. homedir .. "/.awesome_bar\" | sed -z \"s/\\n/ | /g\"'", 1),
            -- spr, -- not needed after calling .awesome_bar
            wibox.widget.systray(),
            spr,
            mytextclock,
        },
    }
end

theme.icon_theme = nil

return theme

-- vim: filetype=lua:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:textwidth=80
